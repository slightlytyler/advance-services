var fetchCollection = require('./fetchCollection');

module.exports = {
  fetchCollection,
};
